import { useEffect, useRef, useState, useCallback } from "react";

const API_URL = import.meta.env.VITE_API_URL;

// POST helper
async function postJSON(path, body) {
  const res = await fetch(`${API_URL}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json().catch(() => ({}));
}

export default function useWS() {
  const esRef = useRef(null);
  const [connected, setConnected] = useState(false);
  const [latencyMs] = useState(null); // no hay ping con SSE
  const [telemetry, setTelemetry] = useState(null);
  const [snapshot, setSnapshot] = useState(null);
  const [steps, setSteps] = useState([]);

  // Mapea comandos “ricos” de la UI a los 5 del backend
  function mapToSimple(cmd) {
    switch (cmd) {
      case "move_forward":  return "adelante";
      case "move_backward": return "atras";
      case "turn_left":     return "izquierda";
      case "turn_right":    return "derecha";
      case "stop":          return "stop";
      default: return null;
    }
  }

  // Enviar orden de movimiento (POST /api/commands)
  const sendControl = useCallback(async (cmd /*, args={}, robotId */) => {
    const simple = mapToSimple(cmd);
    if (!simple) return Promise.reject(new Error(`Comando no soportado por el backend: ${cmd}`));
    return postJSON("/api/commands", { command: simple });
  }, []);

  // Cambiar modo (no soportado por el back actual; no rompemos UI)
  const setMode = useCallback(async () => {
    console.warn("setMode(): backend actual no expone este comando. Ignorado.");
    return { ok: true };
  }, []);

  // Subir imagen (simula “sacar foto” mientras agregan el comando en back)
  const uploadImage = useCallback(async (file) => {
    const fd = new FormData();
    fd.append("image", file);
    const res = await fetch(`${API_URL}/api/images/upload`, { method: "POST", body: fd });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    setSnapshot({ snapshotUrl: data.url, ts: Date.now() });
    return data;
  }, []);

  // Estado en tiempo real por SSE
  useEffect(() => {
    const es = new EventSource(`${API_URL}/api/status/stream`);
    esRef.current = es;
    setConnected(true);

    es.onmessage = (ev) => {
      try { setTelemetry(JSON.parse(ev.data)); } catch {}
    };
    es.onerror = () => { setConnected(false); };

    // estado inicial por HTTP (por si el stream tarda)
    fetch(`${API_URL}/api/status`)
      .then(r => r.json())
      .then(({ lastState }) => setTelemetry(lastState))
      .catch(() => {});

    return () => { try { es.close(); } catch {} };
  }, []);

  return { connected, latencyMs, telemetry, snapshot, steps, setSteps, sendControl, setMode, uploadImage };
}
