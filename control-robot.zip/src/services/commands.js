// src/services/commands.js
const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3000";
const ROBOT_ID = import.meta.env.VITE_ROBOT_ID || "507f1f77bcf86cd799439011";

let cachedMode = null; // "arch" | "control" | "simple"
let cachedPath = null; // endpoint ganador

function logChosen() {
  if (cachedMode && cachedPath) {
    console.info(`[commands] usando ${cachedMode} → ${cachedPath}`);
  }
}

async function tryFetch(path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (res.ok) return { ok: true, json: await res.json().catch(() => ({})) };
  return { ok: false, status: res.status, text: await res.text().catch(() => "") };
}

async function sendCommandAuto(variants) {
  // Si ya detectamos, usar eso directamente
  if (cachedMode && cachedPath) {
    const chosen = variants.find(v => v.mode === cachedMode && v.path === cachedPath);
    if (chosen) return tryFetch(chosen.path, chosen.body);
  }
  // Probar en orden
  for (const v of variants) {
    const r = await tryFetch(v.path, v.body);
    if (r.ok) {
      cachedMode = v.mode;
      cachedPath = v.path;
      logChosen();
      return r;
    }
  }
  return { ok: false, error: `Ningún endpoint aceptó: ${variants.map(x => x.path).join(", ")}` };
}

// ---------- APIs de alto nivel ----------
export async function sendMove(direction) {
  const variants = [
    { mode: "arch",    path: "/api/robot/command",    body: { robotId: ROBOT_ID, commandType: "move", content: { direction } } },
    { mode: "control", path: "/api/commands/control", body: { robotId: ROBOT_ID, task: direction === "forward" ? "move_forward" : "move_backward", args: {} } },
    { mode: "simple",  path: "/api/commands",         body: { command: direction === "forward" ? "adelante" : "atras" } },
  ];
  return sendCommandAuto(variants);
}
export async function sendTurn(direction) {
  const variants = [
    { mode: "arch",    path: "/api/robot/command",    body: { robotId: ROBOT_ID, commandType: "turn", content: { direction } } },
    { mode: "control", path: "/api/commands/control", body: { robotId: ROBOT_ID, task: direction === "left" ? "turn_left" : "turn_right", args: {} } },
    { mode: "simple",  path: "/api/commands",         body: { command: direction === "left" ? "izquierda" : "derecha" } },
  ];
  return sendCommandAuto(variants);
}
export async function sendLift(direction) {
  const variants = [
    { mode: "arch",    path: "/api/robot/command",    body: { robotId: ROBOT_ID, commandType: "lift", content: { direction } } },
    { mode: "control", path: "/api/commands/control", body: { robotId: ROBOT_ID, task: direction === "up" ? "lift_up" : "lift_down", args: {} } },
  ];
  return sendCommandAuto(variants);
}
export async function sendTilt(direction) {
  const variants = [
    { mode: "arch",    path: "/api/robot/command",    body: { robotId: ROBOT_ID, commandType: "tilt", content: { direction } } },
    { mode: "control", path: "/api/commands/control", body: { robotId: ROBOT_ID, task: direction === "up" ? "tilt_up" : "tilt_down", args: {} } },
  ];
  return sendCommandAuto(variants);
}
export async function setMode(mode) {
  const variants = [
    { mode: "arch", path: "/api/robot/command", body: { robotId: ROBOT_ID, commandType: "mode", content: { mode } } },
  ];
  return sendCommandAuto(variants);
}
export async function startAuto() {
  const variants = [
    { mode: "arch", path: "/api/robot/command", body: { robotId: ROBOT_ID, commandType: "start" } },
  ];
  return sendCommandAuto(variants);
}
export async function stopAll() {
  const variants = [
    { mode: "arch",    path: "/api/robot/command",    body: { robotId: ROBOT_ID, commandType: "stop" } },
    { mode: "control", path: "/api/commands/control", body: { robotId: ROBOT_ID, task: "stop", args: {} } },
    { mode: "simple",  path: "/api/commands",         body: { command: "stop" } },
  ];
  return sendCommandAuto(variants);
}
export async function takePhoto() {
  const variants = [
    { mode: "arch",    path: "/api/robot/command",    body: { robotId: ROBOT_ID, commandType: "take_photo", content: {} } },
    { mode: "control", path: "/api/commands/control", body: { robotId: ROBOT_ID, task: "capture_image", args: {} } },
  ];
  return sendCommandAuto(variants);
}
