// src/services/commands.js
const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3000";
const ROBOT_ID = import.meta.env.VITE_ROBOT_ID || "507f1f77bcf86cd799439011";

// cache de la combinación que funcionó
let cached = null; // { path, variant }  variant ∈ 'arch' | 'task' | 'simple'

function m(direction, map) { return map[direction]; }

const MAPS = {
  moveTask:   { forward: "move_forward",  backward: "move_backward" },
  turnTask:   { left: "turn_left",        right: "turn_right" },
  liftTask:   { up: "lift_up",            down: "lift_down" },
  tiltTask:   { up: "tilt_up",            down: "tilt_down" },

  moveSimple: { forward: "adelante",      backward: "atras" },
  turnSimple: { left: "izquierda",        right: "derecha" },
  stopSimple: "stop",
};

async function post(path, body) {
  try {
    const res = await fetch(`${API_BASE}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      return { ok: false, status: res.status, text: txt };
    }
    return { ok: true, json: await res.json().catch(() => ({})) };
  } catch (e) {
    return { ok: false, status: 0, text: String(e) };
  }
}

async function tryCombos(combos) {
  // si ya tenemos una combinación ganadora, probar esa primero
  if (cached) {
    const chosen = combos.find(c => c.path === cached.path && c.variant === cached.variant);
    if (chosen) {
      const r = await post(chosen.path, chosen.body());
      if (r.ok) return r;
    }
  }
  // probar en orden hasta que alguna devuelva 2xx
  for (const c of combos) {
    const r = await post(c.path, c.body());
    if (r.ok) {
      cached = { path: c.path, variant: c.variant };
      console.info(`[commands] usando ${c.variant} → ${c.path}`);
      return r;
    }
  }
  // si ninguna pasó, reportar el último estado
  const last = combos[combos.length - 1];
  return { ok: false, error: `Ningún formato aceptado en ${last.path}` };
}

/* ==================== Acciones de alto nivel ==================== */

export async function sendMove(direction) {
  const combos = [
    // arquitectura pactada
    { variant: "arch",   path: "/api/robot/command",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", commandType: "move", content: { direction } }) },
    // task/args
    { variant: "task",   path: "/api/commands/control",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", task: m(direction, MAPS.moveTask), args: {} }) },
    // simple (comandos en español)
    { variant: "simple", path: "/api/commands",
      body: () => ({ command: m(direction, MAPS.moveSimple) }) },
  ];
  return tryCombos(combos);
}

export async function sendTurn(direction) {
  const combos = [
    { variant: "arch",   path: "/api/robot/command",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", commandType: "turn", content: { direction } }) },
    { variant: "task",   path: "/api/commands/control",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", task: m(direction, MAPS.turnTask), args: {} }) },
    { variant: "simple", path: "/api/commands",
      body: () => ({ command: m(direction, MAPS.turnSimple) }) },
  ];
  return tryCombos(combos);
}

export async function sendLift(direction) {
  const combos = [
    { variant: "arch",   path: "/api/robot/command",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", commandType: "lift", content: { direction } }) },
    { variant: "task",   path: "/api/commands/control",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", task: m(direction, MAPS.liftTask), args: {} }) },
  ];
  return tryCombos(combos);
}

export async function sendTilt(direction) {
  const combos = [
    { variant: "arch",   path: "/api/robot/command",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", commandType: "tilt", content: { direction } }) },
    { variant: "task",   path: "/api/commands/control",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", task: m(direction, MAPS.tiltTask), args: {} }) },
  ];
  return tryCombos(combos);
}

export async function setMode(mode) {
  const combos = [
    { variant: "arch",   path: "/api/robot/command",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", commandType: "mode", content: { mode } }) },
    { variant: "task",   path: "/api/commands/control",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", task: "change_mode", args: { value: mode } }) },
  ];
  return tryCombos(combos);
}

export async function startAuto() {
  const combos = [
    { variant: "arch",   path: "/api/robot/command",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", commandType: "start" }) },
    { variant: "task",   path: "/api/commands/control",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", task: "start_route", args: {} }) },
  ];
  return tryCombos(combos);
}

export async function stopAll() {
  const combos = [
    { variant: "arch",   path: "/api/robot/command",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", commandType: "stop" }) },
  // si el back viejo existe:
    { variant: "task",   path: "/api/commands/control",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", task: "stop", args: {} }) },
    { variant: "simple", path: "/api/commands",
      body: () => ({ command: MAPS.stopSimple }) },
  ];
  return tryCombos(combos);
}

export async function takePhoto() {
  const combos = [
    { variant: "arch",   path: "/api/robot/command",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", commandType: "take_photo", content: {} }) },
    { variant: "task",   path: "/api/commands/control",
      body: () => ({ robotId: ROBOT_ID, source: "web_ui", task: "capture_image", args: {} }) },
  ];
  return tryCombos(combos);
}
