// src/pages/ControlMobile.jsx
import { useEffect, useState, useCallback } from "react";
import useWS from "../hooks/useWS.js";
import Header from "../components/Header.jsx";
import PowerSwitch from "../components/PowerSwitch.jsx";



export default function ControlMobile() {
  const robotId = "R1";
  const isAuto   = mode === "auto";
const running  = telemetry?.status === "running";
const paused   = telemetry?.status === "paused"

  // del hook WS que ya venías usando
  const {
    connected, latencyMs, telemetry, snapshot,
    sendControl, setMode
  } = useWS();

  // estado local de UI
  const [mode, setLocalMode] = useState("manual");   // "manual" | "auto"
  const power = telemetry?.power ?? "on";            // "on" | "off"

  useEffect(() => { if (telemetry?.mode) setLocalMode(telemetry.mode); }, [telemetry?.mode]);

  // ---- Acciones (mapean a los mismos comandos que ya usás) ----
  const toggleMode = () => {
    const next = mode === "auto" ? "manual" : "auto";
    setLocalMode(next);
    setMode(next, robotId);                           // WS → {type:"mode", value}
  };

  const togglePower = () => {
    const next = power === "on" ? "off" : "on";
    sendControl(next === "on" ? "power_on" : "power_off", {}, robotId);
  };

  const onTogglePower = (checked) => {
  sendControl(checked ? "power_on" : "power_off", {}, robotId);
};

  // movimiento discreto (teclitas)
  const move = (task) => () => sendControl(task, {}, robotId);
  // torre: mantener mientras se presiona (soporta mouse/touch/pointer)
  const startLift = (dir) => (e) => { e.preventDefault(); sendControl(dir, {}, robotId); };
  const stopLift  = (e) => { e.preventDefault(); sendControl("lift_stop", {}, robotId); };
  const onPause = () => {
  if (isAuto && running) return sendControl("pause_route", {}, robotId);
  // si no está en automático o no está corriendo, que sea STOP normal
  return sendControl("stop", {}, robotId);
};

  // inclinar torre (si más adelante lo conectan en backend)
  const tilt = (dir) => () => sendControl(dir, {}, robotId); // 'tilt_forward' | 'tilt_backward'

  const takePhoto = () => sendControl("capture_image", {}, robotId);

  // botón principal (solo en automático)
  const isAuto = mode === "auto";
  const running = telemetry?.status === "running"; // o lo que publique su backend
  // botón primario: INICIAR / REANUDAR / PARAR
const onPrimary = () => {
  if (!isAuto) return; // solo en automático
  if (running) return sendControl("stop", {}, robotId);           // termina la ruta
  if (paused)  return sendControl("resume_route", {}, robotId);   // reanuda
  return sendControl("start_route", {}, robotId);                 // inicia
};

  // datos arriba
  const battery = telemetry?.battery ?? "--";
  const status  = telemetry?.status  ?? "--";
  const mast    = telemetry?.mast    ?? "--";
  const ms      = Number.isFinite(latencyMs) ? `${latencyMs} ms` : "— ms";

  // descripción para la card de imagen (IA o QR)
  const imageDesc = snapshot?.description || telemetry?.currentTask || "—";

  return (
    <div className="screen">

      {/* HEADER */}
      <Header
  title="LiftCore"
  onMenu={() => alert("Abrir menú lateral / opciones")}
/>

      {/* BAR DE ESTADO (batería/estado/modo/torre/latencia) */}
      <div className="status-strip">
        <span className="chip ok">SOS</span>
        <span>Batería: <strong>{battery}%</strong></span>
        <span>Estado: <strong>{status}</strong></span>
        <span>Modo: <strong>{mode}</strong></span>
        <span>Torre: <strong>{mast}</strong></span>
        <span className="chip">{ms}</span>
      </div>

      {/* CONTROLES SUPERIORES: Power, tabs de modo y cámara */}
      <div className="row spaced">
  <PowerSwitch
  checked={(telemetry?.power ?? "on") === "on"}
  onCheckedChange={(checked) =>
    sendControl(checked ? "power_on" : "power_off", {}, robotId)
  }
/>

  <div className="segmented">
    <button className={`seg ${mode === "auto" ? "active" : ""}`} onClick={() => (mode !== "auto" ? toggleMode() : null)}>Automático</button>
    <button className={`seg ${mode === "manual" ? "active" : ""}`} onClick={() => (mode !== "manual" ? toggleMode() : null)}>Manual</button>
  </div>

  <button className="icon-btn" title="Tomar foto" onClick={() => sendControl("capture_image", {}, robotId)}>📷</button>
</div>

      {/* CARD: última imagen + descripción IA */}
      <section className="card">
        <div className="snapshot">
          {snapshot?.snapshotUrl
            ? <img src={snapshot.snapshotUrl} alt="Última captura" />
            : <div className="placeholder" />}
        </div>
        <div className="caption">{imageDesc}</div>
      </section>

      {/* CARD: “paso actual” (texto simple) */}
      <section className="card mini">
        <div className="mini-left">⚠️</div>
        <div className="mini-mid">
          <div className="metric">100</div>
          <div className="muted">Body text</div>
        </div>
      </section>

      {/* BOTONERA DE DIRECCIÓN */}
      <section className="pad">
  <button className="pad-btn up"    onClick={() => sendControl("move_forward", {}, robotId)}>▲</button>
  <div className="pad-middle">
    <button className="pad-btn left"  onClick={() => sendControl("turn_left", {}, robotId)}>◀</button>
    <button className="pad-btn pause" onClick={onPause}>⏸</button>
    <button className="pad-btn right" onClick={() => sendControl("turn_right", {}, robotId)}>▶</button>
  </div>
  <button className="pad-btn down"  onClick={() => sendControl("move_backward", {}, robotId)}>▼</button>
</section>

      {/* TORRE: subir/bajar + inclinar */}
      <div className="row two">
        <button
          className="btn"
          onPointerDown={startLift("lift_up")}
          onPointerUp={stopLift}
          onPointerCancel={stopLift}
          onPointerLeave={stopLift}
        >
          SUBIR TORRE
        </button>

        <button
          className="btn"
          onPointerDown={startLift("lift_down")}
          onPointerUp={stopLift}
          onPointerCancel={stopLift}
          onPointerLeave={stopLift}
        >
          BAJAR TORRE
        </button>
      </div>

      <div className="row two">
        <button className="btn" onClick={tilt("tilt_forward")}>INCLINAR ↑</button>
        <button className="btn" onClick={tilt("tilt_backward")}>INCLINAR ↓</button>
      </div>

      {/* BOTÓN PRINCIPAL (solo modo auto) */}
      <button
  className="btn primary block"
  disabled={!isAuto}
  onClick={onPrimary}
  title={isAuto ? "" : "Disponible sólo en modo Automático"}
>
  {running ? "PARAR" : paused ? "REANUDAR" : "INICIAR"}
</button>

      {/* E-STOP */}
      <button className="estop" onClick={move("stop")}>E-STOP</button>

      {/* info de conexión WS */}
      <div className="muted small" style={{marginTop:8}}>
        Stream: {connected ? "Conectado" : "Cortado"}
      </div>
    </div>
  );
}
