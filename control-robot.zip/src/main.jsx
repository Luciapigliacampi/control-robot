// src/main.jsx
import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { Auth0Provider } from "@auth0/auth0-react";
import App from "./App.jsx";
import "./ui.css";



const domain = import.meta.env.VITE_AUTH0_DOMAIN;
const clientId = import.meta.env.VITE_AUTH0_CLIENT_ID;
const audience = import.meta.env.VITE_AUTH0_AUDIENCE; // opcional
const redirectUri = import.meta.env.VITE_REDIRECT_URI || (window.location.origin + "/control");

// src/main.jsx (solo estas líneas)
const bypass  = import.meta.env.VITE_BYPASS_AUTH === "true";
const hasAuth = !bypass && Boolean(domain && clientId);

const authorizationParams = { redirect_uri: redirectUri };
if (audience) authorizationParams.audience = audience;

const Root = (
  <React.StrictMode>
    {hasAuth ? (
      <Auth0Provider
        domain={domain}
        clientId={clientId}
        authorizationParams={authorizationParams}
        cacheLocation="localstorage"
        useRefreshTokens={true}
      >
        <BrowserRouter>
          <App />
        </BrowserRouter>
      </Auth0Provider>
    ) : (
      <BrowserRouter>
        <App />
      </BrowserRouter>
    )}
  </React.StrictMode>
);

ReactDOM.createRoot(document.getElementById("root")).render(Root);
