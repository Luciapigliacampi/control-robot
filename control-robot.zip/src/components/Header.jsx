// src/components/Header.jsx
import React from "react";

// Si usás Auth0 y querés foto real del usuario, descomentá:
// import { useAuth0 } from "@auth0/auth0-react";

export default function Header({ title = "LiftCore", onMenu }) {
  // const { user, isAuthenticated } = useAuth0();
  // const avatarUrl = isAuthenticated ? user?.picture : null;

  const avatarUrl = null; // placeholder si no usás Auth0 aún

  return (
    <header className="hc-header">
      <div className="hc-left">
        {avatarUrl ? (
          <img src={avatarUrl} alt="user avatar" className="hc-avatar" />
        ) : (
          <div className="hc-avatar hc-avatar--placeholder" />
        )}
      </div>

      <div className="hc-title" aria-label={title}>{title}</div>

      <button
        className="hc-iconbtn"
        aria-label="Abrir menú"
        onClick={onMenu}
        type="button"
      >
        {/* Hamburguesa */}
        <span className="hc-burger">
          <i />
          <i />
          <i />
        </span>
      </button>
    </header>
  );
}
