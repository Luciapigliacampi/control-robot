import * as Switch from "@radix-ui/react-switch";

export default function PowerSwitch({ checked, onCheckedChange }) {
  return (
    <form>
      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
        <label htmlFor="power-switch" style={{ color: "#333", fontSize: 14 }}>
          {checked ? "Robot encendido" : "Robot apagado"}
        </label>

        <Switch.Root
          id="power-switch"
          checked={checked}
          onCheckedChange={onCheckedChange}
          className="SwitchRoot"
        >
          <Switch.Thumb className="SwitchThumb" />
        </Switch.Root>
      </div>
    </form>
  );
}
